import { ClientPage } from "@/components/ClientPage";
import ErrorPage from "@/components/ErrorPage";
import { Layout } from "@/components/Layout";
import QueryClientProvider from "@/components/QueryClientProvider";
import { Toaster } from "@/components/ui/toaster";
import { AppStateProvider } from "@/contexts/AppStateProvider";
import { useAuth } from "@/contexts/AuthContext";
import { useAuthErrorListener } from "@/lib/api";
import { getApiKey } from "@/lib/auth";
import { LoaderCircleIcon } from "lucide-react";
import { useEffect, useState } from "react";

function App() {
  const [websocketEnabled, setWebsocketEnabled] = useState<boolean>();
  const [webrtcEnabled, setWebrtcEnabled] = useState<boolean>();
  const [dailyEnabled, setDailyEnabled] = useState<boolean>();
  const { isAuthenticated } = useAuth();
  
  // 监听认证错误
  useAuthErrorListener();

  useEffect(() => {
    const fetchServerStatus = async () => {
      try {
        const apiKey = getApiKey();
        const headers: HeadersInit = {};
        
        if (apiKey) {
          headers['Authorization'] = `Bearer ${apiKey}`;
        }
        
        const response = await fetch(`${import.meta.env.VITE_SERVER_URL}/`, {
          headers
        });
        
        // 检查是否是认证错误
        if (response.status === 403 || response.status === 401) {
          // 触发认证对话框
          const authEvent = new CustomEvent('auth:unauthorized');
          window.dispatchEvent(authEvent);
          throw new Error('Authentication failed');
        }
        
        const json = await response.json();
        setWebsocketEnabled(json?.["websocket-enabled"] ?? false);
        setWebrtcEnabled(json?.["webrtc-enabled"] ?? false);
        setDailyEnabled(json?.["daily-enabled"] ?? false);
      } catch (error) {
        console.error('Error fetching server status:', error);
        setWebsocketEnabled(false);
        setWebrtcEnabled(false);
        setDailyEnabled(false);
      }
    };
    
    fetchServerStatus();
  }, [isAuthenticated]);

  if (websocketEnabled === undefined && webrtcEnabled === undefined) {
    return (
      <Layout>
        <div className="h-full flex items-center justify-center">
          <LoaderCircleIcon className="animate-spin" />
        </div>
      </Layout>
    );
  }

  if (!websocketEnabled && !webrtcEnabled) {
    return (
      <ErrorPage title="Missing configuration">
        <code>WebRTC</code> or{" "} <code>WebSocket</code> disabled.
      </ErrorPage>
    );
  }

  return (
    <QueryClientProvider>
      <AppStateProvider
        dailyEnabled={dailyEnabled ?? false}
        webrtcEnabled={webrtcEnabled ?? false}
        websocketEnabled={websocketEnabled ?? false}
      >
        <Layout>
          <ClientPage />
          <Toaster />
        </Layout>
      </AppStateProvider>
    </QueryClientProvider>
  );
}

export default App;
