import { ConversationModel } from "@/lib/conversations";
import { Message } from "@/lib/messages";

interface MockConversation extends ConversationModel {
  messages: Message[];
}

export const mockConversations: MockConversation[] = [
  {
    conversation_id: "06207f42-9309-4645-9b30-131117cc8c96",
    title: "Mock Conversation 82",
    created_at: "2024-11-27T09:54:56.841974",
    updated_at: "2024-11-27T10:28:04.841974",
    messages: [
      {
        created_at: "2024-11-27T09:54:56.841974",
        content: {
          role: "system",
          content: "Instruction for the bot 42",
          tool_calls: [],
        },
        conversation_id: "06207f42-9309-4645-9b30-131117cc8c96",
        extra_metadata: null,
        message_id: "8158ecd7-0b3f-439c-bb23-db77a0d44c48",
        message_number: 1,
        updated_at: "2024-11-27T09:54:56.841974",
      },
      {
        created_at: "2024-11-27T09:56:20.841974",
        content: {
          role: "user",
          content: [
            {
              type: "text",
              text: "Hello, I need help with something.",
            },
          ],
          tool_calls: [],
        },
        conversation_id: "06207f42-9309-4645-9b30-131117cc8c96",
        extra_metadata: null,
        message_id: "8158ecd7-0b3f-439c-bb23-db77a0d44c49",
        message_number: 2,
        updated_at: "2024-11-27T09:56:20.841974",
      },
      {
        created_at: "2024-11-27T09:56:30.841974",
        content: {
          role: "assistant",
          content: [
            {
              type: "text",
              text: "Hello! I'm here to help. What can I assist you with today?",
            },
          ],
          tool_calls: [],
        },
        conversation_id: "06207f42-9309-4645-9b30-131117cc8c96",
        extra_metadata: null,
        message_id: "8158ecd7-0b3f-439c-bb23-db77a0d44c50",
        message_number: 3,
        updated_at: "2024-11-27T09:56:30.841974",
      },
      {
        created_at: "2024-11-27T09:57:00.841974",
        content: {
          role: "user",
          content: [
            {
              type: "text",
              text: "I need help with my project.",
            },
          ],
          tool_calls: [],
        },
        conversation_id: "06207f42-9309-4645-9b30-131117cc8c96",
        extra_metadata: null,
        message_id: "8158ecd7-0b3f-439c-bb23-db77a0d44c51",
        message_number: 4,
        updated_at: "2024-11-27T09:57:00.841974",
      },
      {
        created_at: "2024-11-27T09:57:15.841974",
        content: {
          role: "assistant",
          content: [
            {
              type: "image_url",
              image_url: {
                url: "https://example.com/image1.jpg",
              },
            },
          ],
          tool_calls: [],
        },
        conversation_id: "06207f42-9309-4645-9b30-131117cc8c96",
        extra_metadata: null,
        message_id: "8158ecd7-0b3f-439c-bb23-db77a0d44c52",
        message_number: 5,
        updated_at: "2024-11-27T09:57:15.841974",
      },
      {
        created_at: "2024-11-27T09:58:00.841974",
        content: {
          role: "user",
          content: [
            {
              type: "text",
              text: "That's helpful, thank you!",
            },
          ],
          tool_calls: [],
        },
        conversation_id: "06207f42-9309-4645-9b30-131117cc8c96",
        extra_metadata: null,
        message_id: "8158ecd7-0b3f-439c-bb23-db77a0d44c53",
        message_number: 6,
        updated_at: "2024-11-27T09:58:00.841974",
      },
      {
        created_at: "2024-11-27T09:58:15.841974",
        content: {
          role: "assistant",
          content: [
            {
              type: "image_url",
              image_url: {
                url: "https://example.com/image2.jpg",
              },
            },
          ],
          tool_calls: [],
        },
        conversation_id: "06207f42-9309-4645-9b30-131117cc8c96",
        extra_metadata: null,
        message_id: "8158ecd7-0b3f-439c-bb23-db77a0d44c54",
        message_number: 7,
        updated_at: "2024-11-27T09:58:15.841974",
      },
      {
        created_at: "2024-11-27T09:59:00.841974",
        content: {
          role: "user",
          content: [
            {
              type: "image_url",
              image_url: {
                url: "https://example.com/user-image1.jpg",
              },
            },
          ],
          tool_calls: [],
        },
        conversation_id: "06207f42-9309-4645-9b30-131117cc8c96",
        extra_metadata: null,
        message_id: "8158ecd7-0b3f-439c-bb23-db77a0d44c55",
        message_number: 8,
        updated_at: "2024-11-27T09:59:00.841974",
      },
      {
        created_at: "2024-11-27T09:59:30.841974",
        content: {
          role: "assistant",
          content: [
            {
              type: "image_url",
              image_url: {
                url: "https://example.com/image3.jpg",
              },
            },
          ],
          tool_calls: [],
        },
        conversation_id: "06207f42-9309-4645-9b30-131117cc8c96",
        extra_metadata: null,
        message_id: "8158ecd7-0b3f-439c-bb23-db77a0d44c56",
        message_number: 9,
        updated_at: "2024-11-27T09:59:30.841974",
      },
      {
        created_at: "2024-11-27T10:00:00.841974",
        content: {
          role: "user",
          content: [
            {
              type: "text",
              text: "Can you explain this concept?",
            },
          ],
          tool_calls: [],
        },
        conversation_id: "06207f42-9309-4645-9b30-131117cc8c96",
        extra_metadata: null,
        message_id: "8158ecd7-0b3f-439c-bb23-db77a0d44c57",
        message_number: 10,
        updated_at: "2024-11-27T10:00:00.841974",
      },
      {
        created_at: "2024-11-27T10:00:30.841974",
        content: {
          role: "assistant",
          content: [
            {
              type: "text",
              text: "Certainly! Here's an explanation of the concept you asked about...",
            },
          ],
          tool_calls: [],
        },
        conversation_id: "06207f42-9309-4645-9b30-131117cc8c96",
        extra_metadata: null,
        message_id: "8158ecd7-0b3f-439c-bb23-db77a0d44c58",
        message_number: 11,
        updated_at: "2024-11-27T10:00:30.841974",
      },
      {
        created_at: "2024-11-27T10:01:00.841974",
        content: {
          role: "user",
          content: [
            {
              type: "text",
              text: "Thanks for the explanation.",
            },
          ],
          tool_calls: [],
        },
        conversation_id: "06207f42-9309-4645-9b30-131117cc8c96",
        extra_metadata: null,
        message_id: "8158ecd7-0b3f-439c-bb23-db77a0d44c59",
        message_number: 12,
        updated_at: "2024-11-27T10:01:00.841974",
      },
      {
        created_at: "2024-11-27T10:01:30.841974",
        content: {
          role: "assistant",
          content: [
            {
              type: "text",
              text: "You're welcome! Is there anything else you'd like to know?",
            },
          ],
          tool_calls: [],
        },
        conversation_id: "06207f42-9309-4645-9b30-131117cc8c96",
        extra_metadata: null,
        message_id: "8158ecd7-0b3f-439c-bb23-db77a0d44c60",
        message_number: 13,
        updated_at: "2024-11-27T10:01:30.841974",
      },
      {
        created_at: "2024-11-27T10:02:00.841974",
        content: {
          role: "user",
          content: [
            {
              type: "text",
              text: "No, that's all for now.",
            },
          ],
          tool_calls: [],
        },
        conversation_id: "06207f42-9309-4645-9b30-131117cc8c96",
        extra_metadata: null,
        message_id: "8158ecd7-0b3f-439c-bb23-db77a0d44c61",
        message_number: 14,
        updated_at: "2024-11-27T10:02:00.841974",
      },
      {
        created_at: "2024-11-27T10:02:30.841974",
        content: {
          role: "assistant",
          content: [
            {
              type: "text",
              text: "Alright! Feel free to reach out if you have any more questions in the future. Have a great day!",
            },
          ],
          tool_calls: [],
        },
        conversation_id: "06207f42-9309-4645-9b30-131117cc8c96",
        extra_metadata: null,
        message_id: "8158ecd7-0b3f-439c-bb23-db77a0d44c62",
        message_number: 15,
        updated_at: "2024-11-27T10:02:30.841974",
      },
      {
        created_at: "2024-11-27T10:03:00.841974",
        content: {
          role: "user",
          content: [
            {
              type: "text",
              text: "Actually, I have one more question.",
            },
          ],
          tool_calls: [],
        },
        conversation_id: "06207f42-9309-4645-9b30-131117cc8c96",
        extra_metadata: null,
        message_id: "8158ecd7-0b3f-439c-bb23-db77a0d44c63",
        message_number: 16,
        updated_at: "2024-11-27T10:03:00.841974",
      },
      {
        created_at: "2024-11-27T10:03:30.841974",
        content: {
          role: "assistant",
          content: [
            {
              type: "text",
              text: "Of course! I'm happy to help. What's your question?",
            },
          ],
          tool_calls: [],
        },
        conversation_id: "06207f42-9309-4645-9b30-131117cc8c96",
        extra_metadata: null,
        message_id: "8158ecd7-0b3f-439c-bb23-db77a0d44c64",
        message_number: 17,
        updated_at: "2024-11-27T10:03:30.841974",
      },
      {
        created_at: "2024-11-27T10:04:00.841974",
        content: {
          role: "user",
          content: [
            {
              type: "text",
              text: "How do I implement this feature?",
            },
          ],
          tool_calls: [],
        },
        conversation_id: "06207f42-9309-4645-9b30-131117cc8c96",
        extra_metadata: null,
        message_id: "8158ecd7-0b3f-439c-bb23-db77a0d44c65",
        message_number: 18,
        updated_at: "2024-11-27T10:04:00.841974",
      },
      {
        created_at: "2024-11-27T10:04:30.841974",
        content: {
          role: "assistant",
          content: [
            {
              type: "text",
              text: "To implement this feature, you'll need to follow these steps...",
            },
          ],
          tool_calls: [],
        },
        conversation_id: "06207f42-9309-4645-9b30-131117cc8c96",
        extra_metadata: null,
        message_id: "8158ecd7-0b3f-439c-bb23-db77a0d44c66",
        message_number: 19,
        updated_at: "2024-11-27T10:04:30.841974",
      },
    ],
  },
  {
    conversation_id: "16207f42-9309-4645-9b30-131117cc8c97",
    title: "Mock Conversation 83",
    created_at: "2024-11-27T11:54:56.841974",
    updated_at: "2024-11-27T12:28:04.841974",
    messages: [
      {
        created_at: "2024-11-27T11:54:56.841974",
        content: {
          role: "system",
          content: "Instruction for the bot 43",
          tool_calls: [],
        },
        conversation_id: "16207f42-9309-4645-9b30-131117cc8c97",
        extra_metadata: null,
        message_id: "9158ecd7-0b3f-439c-bb23-db77a0d44c48",
        message_number: 1,
        updated_at: "2024-11-27T11:54:56.841974",
      },
      {
        created_at: "2024-11-27T11:56:20.841974",
        content: {
          role: "user",
          content: [
            {
              type: "image_url",
              image_url: {
                url: "https://example.com/user-image2.jpg",
              },
            },
          ],
          tool_calls: [],
        },
        conversation_id: "16207f42-9309-4645-9b30-131117cc8c97",
        extra_metadata: null,
        message_id: "9158ecd7-0b3f-439c-bb23-db77a0d44c49",
        message_number: 2,
        updated_at: "2024-11-27T11:56:20.841974",
      },
      {
        created_at: "2024-11-27T11:56:30.841974",
        content: {
          role: "assistant",
          content: [
            {
              type: "text",
              text: "I can see the image you've shared. It appears to be...",
            },
          ],
          tool_calls: [],
        },
        conversation_id: "16207f42-9309-4645-9b30-131117cc8c97",
        extra_metadata: null,
        message_id: "9158ecd7-0b3f-439c-bb23-db77a0d44c50",
        message_number: 3,
        updated_at: "2024-11-27T11:56:30.841974",
      },
      {
        created_at: "2024-11-27T11:57:00.841974",
        content: {
          role: "user",
          content: [
            {
              type: "text",
              text: "Can you analyze this image for me?",
            },
          ],
          tool_calls: [],
        },
        conversation_id: "16207f42-9309-4645-9b30-131117cc8c97",
        extra_metadata: null,
        message_id: "9158ecd7-0b3f-439c-bb23-db77a0d44c51",
        message_number: 4,
        updated_at: "2024-11-27T11:57:00.841974",
      },
      {
        created_at: "2024-11-27T11:57:15.841974",
        content: {
          role: "assistant",
          content: [
            {
              type: "image_url",
              image_url: {
                url: "https://example.com/analysis1.jpg",
              },
            },
          ],
          tool_calls: [],
        },
        conversation_id: "16207f42-9309-4645-9b30-131117cc8c97",
        extra_metadata: null,
        message_id: "9158ecd7-0b3f-439c-bb23-db77a0d44c52",
        message_number: 5,
        updated_at: "2024-11-27T11:57:15.841974",
      },
      {
        created_at: "2024-11-27T11:58:00.841974",
        content: {
          role: "user",
          content: [
            {
              type: "text",
              text: "Thanks for the analysis.",
            },
          ],
          tool_calls: [],
        },
        conversation_id: "16207f42-9309-4645-9b30-131117cc8c97",
        extra_metadata: null,
        message_id: "9158ecd7-0b3f-439c-bb23-db77a0d44c53",
        message_number: 6,
        updated_at: "2024-11-27T11:58:00.841974",
      },
      {
        created_at: "2024-11-27T11:58:15.841974",
        content: {
          role: "assistant",
          content: [
            {
              type: "text",
              text: "You're welcome! Is there anything specific about the image you'd like me to explain further?",
            },
          ],
          tool_calls: [],
        },
        conversation_id: "16207f42-9309-4645-9b30-131117cc8c97",
        extra_metadata: null,
        message_id: "9158ecd7-0b3f-439c-bb23-db77a0d44c54",
        message_number: 7,
        updated_at: "2024-11-27T11:58:15.841974",
      },
    ],
  },
  // Add more mock conversations as needed
  {
    conversation_id: "26207f42-9309-4645-9b30-131117cc8c98",
    title: "Mock Conversation 84",
    created_at: "2024-11-28T09:54:56.841974",
    updated_at: "2024-11-28T10:28:04.841974",
    messages: [
      {
        created_at: "2024-11-28T09:54:56.841974",
        content: {
          role: "system",
          content: "Instruction for the bot 44",
          tool_calls: [],
        },
        conversation_id: "26207f42-9309-4645-9b30-131117cc8c98",
        extra_metadata: null,
        message_id: "0158ecd7-0b3f-439c-bb23-db77a0d44c48",
        message_number: 1,
        updated_at: "2024-11-28T09:54:56.841974",
      },
      {
        created_at: "2024-11-28T09:56:20.841974",
        content: {
          role: "user",
          content: [
            {
              type: "text",
              text: "Hello, can you help me with a coding problem?",
            },
          ],
          tool_calls: [],
        },
        conversation_id: "26207f42-9309-4645-9b30-131117cc8c98",
        extra_metadata: null,
        message_id: "0158ecd7-0b3f-439c-bb23-db77a0d44c49",
        message_number: 2,
        updated_at: "2024-11-28T09:56:20.841974",
      },
      {
        created_at: "2024-11-28T09:56:30.841974",
        content: {
          role: "assistant",
          content: [
            {
              type: "text",
              text: "Of course! I'd be happy to help with your coding problem. Please describe the issue you're facing, and if possible, share any relevant code snippets.",
            },
          ],
          tool_calls: [],
        },
        conversation_id: "26207f42-9309-4645-9b30-131117cc8c98",
        extra_metadata: null,
        message_id: "0158ecd7-0b3f-439c-bb23-db77a0d44c50",
        message_number: 3,
        updated_at: "2024-11-28T09:56:30.841974",
      },
    ],
  },
  // Add more mock conversations as needed
];
