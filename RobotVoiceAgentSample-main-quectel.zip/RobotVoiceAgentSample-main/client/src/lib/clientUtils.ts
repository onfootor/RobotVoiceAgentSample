import { RTVIClient, Participant } from "@pipecat-ai/client-js";
import { SmallWebRTCTransport } from "@pipecat-ai/small-webrtc-transport";
import { DailyTransport } from "@pipecat-ai/daily-transport";
import { getApiKey } from "./auth";

/**
 * Creates an RTVIClient instance based on conversation type
 */
export async function createRTVIClient(conversationType: string | null, conversationId: string | null, model: string): Promise<RTVIClient> {
  let transport;
  if (conversationType === "voice-to-voice" || conversationType === "text-voice") {
    transport = new SmallWebRTCTransport();
    // Set custom ICE servers
    transport.iceServers = [
      { urls: ["stun:stun.miwifi.com:3478", "stun:stun.l.google.com:19302"] },
    ];
  } else {
    transport = new DailyTransport();
  }

  // 获取API密钥
  const apiKey = getApiKey();
  // 创建标准Headers对象
  const headers = new Headers();
  if (apiKey) {
    headers.append('Authorization', `Bearer ${apiKey}`);
  }

  return new RTVIClient({
    enableCam: false,
    enableMic: conversationType === "voice-to-voice",
    transport: transport,
    params: {
      baseUrl: import.meta.env.VITE_SERVER_URL,
      endpoints: {
        connect: transport instanceof SmallWebRTCTransport ? "/offer" : "/bot/connect",
        action: "/bot/action",
      },
      requestData: {
        bot_profile:
          conversationType === "voice-to-voice" ? "nova-sonic" : "bedrock",
        conversation_id: conversationId,
        language: conversationType === "voice-to-voice" ? "English" : "Chinese",
        model: model ?? "Claude Sonnet 3.7",
      },
      headers, // 添加认证头
      config: [
        {
          service: "llm",
          options: [
            {
              name: "model",
              value: "Nova Pro",
            },
            // {
            //   name: "initial_messages",
            //   value: [
            //     {
            //       role: "system",
            //       content:
            //         "You are a assistant called ExampleBot. You can ask me anything. Keep responses brief and legible.",
            //     },
            //   ],
            // },
          ],
        },
      ],
    },
    // This is required for SmallWebRTCTransport
    customConnectHandler: transport instanceof SmallWebRTCTransport ? () => Promise.resolve() : undefined, 
    callbacks: {
      // Transport state changes
      onTransportStateChanged: (state) => {
        console.log(`Transport state: ${state}`);
      },

      // Connection events
      onConnected: () => {
        console.log("Connected to bot");
      },
      onDisconnected: () => {
        console.log("Disconnected from bot");
      },
      onBotReady: () => {
        console.log("Bot is ready.");
      },

      // Speech events
      onUserStartedSpeaking: () => {
        console.log("User started speaking.");
      },
      onUserStoppedSpeaking: () => {
        console.log("User stopped speaking.");
      },
      onBotStartedSpeaking: () => {
        console.log("Bot started speaking.");
      },
      onBotStoppedSpeaking: () => {
        console.log("Bot stopped speaking.");
      },

      // Transcript events
      onUserTranscript: (transcript) => {
        if (transcript.final) {
          console.log(`User transcript: ${transcript.text}`);
        }
      },
      onBotTranscript: (transcript) => {
        console.log(`Bot transcript: ${transcript.text}`);
      },

      // Media tracks
      onTrackStarted: (
        track: MediaStreamTrack,
        participant?: Participant
      ) => {
        if (participant?.local) {
          // Handle local tracks (e.g., self-view)
          if (track.kind === "video") {
            //this.selfViewVideo.srcObject = new MediaStream([track]);
            //this.updateSelfViewVisibility();
          }
          return;
        }
        // Handle remote tracks (the bot)
        //this.onBotTrackStarted(track);
      },

      // Other events
      onServerMessage: (msg) => {
        console.log(`Server message: ${msg}`);
      },
    },
  });
}