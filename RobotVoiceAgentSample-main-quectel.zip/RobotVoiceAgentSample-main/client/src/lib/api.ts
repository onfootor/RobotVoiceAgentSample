import { addAuthHeader } from './auth';
import { useAuth } from '../contexts/AuthContext';
import { useEffect } from 'react';

/**
 * 创建一个拦截器，用于处理API请求的认证和错误
 */
export async function fetchWithAuth(url: string, options: RequestInit = {}): Promise<Response> {
  // 确保headers存在
  const headers = new Headers(options.headers || {});
  
  // 添加认证头
  addAuthHeader(headers);
  
  // 创建新的请求选项，包含认证头
  const authOptions = {
    ...options,
    headers
  };
  
  try {
    const response = await fetch(url, authOptions);
    
    // 如果返回403错误，触发认证对话框
    if (response.status === 403 || response.status === 401) {
      // 我们不能直接在这里访问useAuth，因为这不是一个React组件
      // 而是通过事件触发认证对话框
      const authEvent = new CustomEvent('auth:unauthorized');
      window.dispatchEvent(authEvent);
      throw new Error('Authentication failed');
    }
    
    return response;
  } catch (error) {
    console.error('API request failed:', error);
    throw error;
  }
}

/**
 * 用于在组件中监听认证错误的钩子
 */
export function useAuthErrorListener() {
  const { showApiKeyDialog } = useAuth();
  
  // 监听认证错误事件
  useEffect(() => {
    const handleUnauthorized = () => {
      showApiKeyDialog();
    };
    
    window.addEventListener('auth:unauthorized', handleUnauthorized);
    return () => {
      window.removeEventListener('auth:unauthorized', handleUnauthorized);
    };
  }, [showApiKeyDialog]);
}
