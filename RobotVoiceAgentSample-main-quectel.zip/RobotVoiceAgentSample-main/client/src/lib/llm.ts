export type LLMMessageRole = "system" | "user" | "assistant" | "tool";
