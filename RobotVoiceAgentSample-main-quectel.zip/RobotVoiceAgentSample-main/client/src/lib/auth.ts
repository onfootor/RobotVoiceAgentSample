// 认证相关的常量
const API_KEY_STORAGE_KEY = 'api_key';

/**
 * 从localStorage获取API密钥
 */
export function getApiKey(): string | null {
  return localStorage.getItem(API_KEY_STORAGE_KEY);
}

/**
 * 保存API密钥到localStorage
 */
export function saveApiKey(apiKey: string): void {
  localStorage.setItem(API_KEY_STORAGE_KEY, apiKey);
}

/**
 * 清除存储的API密钥
 */
export function clearApiKey(): void {
  localStorage.removeItem(API_KEY_STORAGE_KEY);
}

/**
 * 检查是否有存储的API密钥
 */
export function hasApiKey(): boolean {
  return !!getApiKey();
}

/**
 * 为请求添加认证头
 */
export function addAuthHeader(headers: Headers): Headers {
  const apiKey = getApiKey();
  if (apiKey) {
    headers.append('Authorization', `Bearer ${apiKey}`);
  }
  return headers;
}
