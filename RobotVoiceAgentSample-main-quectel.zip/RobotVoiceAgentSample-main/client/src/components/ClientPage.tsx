import ChatControls from "@/components/ChatControls";
import ChatMessages from "@/components/ChatMessages";
import DeleteConversationModal from "@/components/DeleteConversationModal";
import Settings from "@/components/Settings";
import { Button } from "@/components/ui/button";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { VoiceIndicator } from "@/components/VoiceIndicator";
import { WebRTCVoiceChat } from "@/components/WebRTCVoiceChat";
import { useAppState } from "@/hooks/useAppState";
import { useConversation } from "@/hooks/useConversation";
import emitter from "@/lib/eventEmitter";
import { RTVIClient } from "@pipecat-ai/client-js";
import { RTVIClientAudio, RTVIClientProvider } from "@pipecat-ai/client-react";
import { createRTVIClient } from "@/lib/clientUtils";
import {
  ArrowDownIcon,
  AudioWaveformIcon,
  DatabaseIcon,
  LoaderCircleIcon,
  XCircleIcon,
} from "lucide-react";
import { useEffect, useLayoutEffect, useState } from "react";
import PipecatLogo from "./svg/Pipecat";
import { createConversation } from "../lib/conversations";

// const defaultRequestData = {
//   bot_profile: "vision",
// };

export function ClientPage() {
  const {
    conversationId,
    setConversationId,
    showMessage,
    setShowMessages,
    conversationType,
    setConversationType,
    dailyEnabled,
    webrtcEnabled,
  } = useAppState();

  const [model, setModel] = useState("Claude Sonnet 3.7");

  const { conversation, isFetching } = useConversation(conversationId);
  const messages = conversation?.messages ?? [];
  const visibleMessages = messages.filter((m) => m.content.role !== "system");

  useEffect(() => {
    const handleShowChatMessages = () => setShowMessages(true);
    emitter.on("showChatMessages", handleShowChatMessages);
    return () => {
      emitter.off("showChatMessages", handleShowChatMessages);
    };
  }, []);
  useEffect(() => {
    if (!conversationType) {
      setShowMessages(false);
    }
  }, [conversationType]);

  const [client, setClient] = useState<RTVIClient>();

  useEffect(() => {
    if (!conversationType) {
      setClient((prevClient) => {
        if (prevClient?.connected) prevClient?.disconnect();
        return undefined;
      });
      return;
    }

    if(conversationType === "voice-to-voice"){
      const newRTVIClient = async () => {
        const newClient = await createRTVIClient(conversationType, conversationId, model);
        if (newClient) {
          setClient(newClient);
        }
      };
      newRTVIClient();
      return;
    } 
    
    if(conversationId) return;

    const newConversation = async () => {
      const result = await createConversation();
      if (result) {
        emitter.emit("updateSidebar");
        setConversationId(result.conversation_id);
      }
    };
    
    newConversation();
  }, [conversationType, dailyEnabled]);


  useEffect(() => {
    if (conversationType === "voice-to-voice" || !conversationId) return;

    const newRTVIClient = async () => {
      const newClient = await createRTVIClient(conversationType, conversationId, model);
      if (newClient) {
        setClient(newClient);
      }
    };
    
    newRTVIClient();

  }, [conversationId, model]);

  // useEffect(() => {
  //   if (!client || !conversationId) return;
  //   client.params.requestData = {
  //     ...defaultRequestData,
  //     ...(client.params.requestData ?? {}),
  //     conversation_id: conversationId,
  //   };
  // }, [client, conversationId]);

  const [showScrollToBottom, setShowScrollToBottom] = useState(false);

  useLayoutEffect(() => {
    const handleScroll = () => {
      const scroller = document.scrollingElement;
      if (!scroller) return;
      const scrollBottom =
        scroller.scrollHeight - scroller.clientHeight - scroller.scrollTop;
      setShowScrollToBottom(
        scroller.scrollHeight > scroller.clientHeight && scrollBottom > 150,
      );
    };
    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  useEffect(() => {
    if (!client) return;
    const handleChangeLlmModel = (model: string) => {
      console.log(`Changing LLM model to: ${model}`);
      
      setModel(model);

      if (client.connected) {
        client.updateConfig([
          {
            service: "llm",
            options: [
              {
                name: "model",
                value: model,
              },
            ],
          },
        ]);
      } else {
        client.params.requestData = {
          ...(client.params.requestData ?? {}),
          model: model,
        };
        const config = client.params.config;
        if (config) {
          const llmConfig = config.find((c) => c.service === "llm");
          client.params.config = [
            ...config,
            {
              service: "llm",
              options: [
                ...(llmConfig?.options ?? []),
                {
                  name: "model",
                  value: model,
                },
              ],
            },
          ];
        } else {
          client.params.config = [
            {
              service: "llm",
              options: [
                {
                  name: "model",
                  value: model,
                },
              ],
            },
          ];
        }
      }
    };
    emitter.on("changeLlmModel", handleChangeLlmModel);
    return () => {
      emitter.off("changeLlmModel", handleChangeLlmModel);
    };
  }, [client]);

  useEffect(() => {
    if (!client) return;
    const isConnected = client.connected;
    const isConnecting =
      client.state === "authenticating" || client.state === "connecting";
    if (isConnecting || isConnected) {
      client.disconnect();
    }
  }, [client, conversationId]);

  return (
    <RTVIClientProvider client={client!}>
      <div className="flex-grow grid grid-cols-1 grid-rows-[1fr_min-content]">
        {/* Messages */}
        <div className="relative flex-grow p-4 pb-8 flex flex-col">
          {conversationType === "voice-to-voice" ? (
            <WebRTCVoiceChat />
          ) : isFetching ? (
            <div className="flex-grow flex items-center justify-center">
              <LoaderCircleIcon className="animate-spin" />
            </div>
          ) : visibleMessages.length > 0 || showMessage ? (
            <ChatMessages
              autoscroll={!showScrollToBottom}
              messages={messages}
            />
          ) : conversationType === "text-voice" ? (
            <div className="flex flex-col gap-4 items-center justify-center h-full my-auto">
              <VoiceIndicator className="shadow-md" size={72} />
              <h2 className="font-semibold text-xl text-center">
                Start chatting
              </h2>
            </div>
          ) : (
            <div className="flex flex-col gap-12 items-center justify-center h-full my-auto">
              <h2 className="font-light text-2xl text-center text-neutral-700">
                Select conversation type:
              </h2>
              <div className="grid md:grid-cols-2 gap-8 lg:gap-12 items-center justify-center">
                <Button
                  disabled={false}
                  variant="secondary-outline"
                  className="relative h-full flex flex-col border border-transparent bg-origin-border borderClip bg-cardBorder justify-between gap-2 max-w-72 lg:max-w-80 text-wrap rounded-3xl p-4 lg:p-6 shadow-mid hover:shadow-long hover:bg-cardBorderHover transition-all text-base outline outline-neutral-400/10 outline-0 hover:outline-[7px]"
                  onClick={() => setConversationType("voice-to-voice")}
                >
                  {!webrtcEnabled && (
                    <div className="bg-red-200 self-stretch absolute -top-4 left-10 right-10 z-10 rounded-full text-xs py-2 uppercase tracking-wider text-red-900">
                      <code>WebRTC</code> disabled
                    </div>
                  )}
                  <div className="flex items-center justify-center bg-sky-100 text-sky-400 rounded-full">
                    <AudioWaveformIcon className="h-20 w-20 p-4" />
                  </div>
                  <div className="flex flex-col gap-2">
                    <strong className="block mt-4 text-lg">
                      Speech to Speech
                    </strong>
                    <span className="font-light text-neutral-500">
                      Use your mic to talk with Nova Sonic using WebRTC.
                    </span>
                  </div>
                  <span className="opacity-50 inline-flex gap-1 items-center mt-4">
                    <XCircleIcon className="text-destructive" size={16} />
                    <span className="uppercase font-light text-neutral-700 text-xs tracking-wider">
                      Conversations not stored
                    </span>
                  </span>
                </Button>
                <Button
                  disabled={!webrtcEnabled}
                  variant="secondary-outline"
                  className="relative h-full flex flex-col items-center border border-transparent bg-origin-border borderClip bg-cardBorder justify-between gap-2 max-w-72 lg:max-w-80 text-wrap rounded-3xl p-4 lg:p-6 shadow-mid hover:shadow-long hover:bg-cardBorderHover transition-all text-base outline outline-neutral-400/10 outline-0 hover:outline-[7px]"
                  onClick={() => setConversationType("text-voice")}
                >
                  {!webrtcEnabled && (
                    <div className="bg-red-200 self-stretch absolute -top-4 left-10 right-10 z-10 rounded-full text-xs py-2 uppercase tracking-wider text-red-900">
                      <code>WebRTC</code> disabled
                    </div>
                  )}
                  <div className="flex items-center justify-center bg-orange-100 text-orange-400 rounded-full">
                    <PipecatLogo className="h-20 w-20 p-4" />
                  </div>
                  <div className="flex flex-col gap-2">
                    <strong className="block mt-4 text-lg">
                      Transcribe - Bedrock - Polly
                    </strong>
                    <span className="font-light text-neutral-500">
                      Use your mic, camera and keyboard to talk with Amazon Bedrock
                      using WebRTC.
                    </span>
                  </div>
                  <span className="opacity-50 inline-flex gap-1 items-center mt-4">
                    <DatabaseIcon className="text-green-400" size={16} />
                    <span className="uppercase font-light text-neutral-700 text-xs tracking-wider">
                      Conversations stored
                    </span>
                  </span>
                </Button>
              </div>
            </div>
          )}
          {showScrollToBottom && (
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    className="rounded-full fixed right-4 bottom-20 z-20"
                    onClick={() =>
                      document.scrollingElement?.scrollTo({
                        behavior: "smooth",
                        top: document.scrollingElement?.scrollHeight,
                      })
                    }
                    size="icon"
                    variant="outline"
                  >
                    <ArrowDownIcon size={16} />
                  </Button>
                </TooltipTrigger>
                <TooltipContent
                  align="center"
                  className="bg-popover text-popover-foreground"
                  side="left"
                >
                  Scroll to bottom
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          )}
        </div>

        {/* Chat controls */}
        {conversationType === "text-voice" && (
          <div className="flex-none bg-background sticky bottom-0 w-full z-10">
            <ChatControls vision />
            {/* Prevents scroll content from showing up below chat controls */}
            <div className="h-4 bg-background w-full" />
          </div>
        )}
      </div>

      <RTVIClientAudio />
      <Settings vision={conversationType === "text-voice"} />
      <DeleteConversationModal />
    </RTVIClientProvider>
  );
}
