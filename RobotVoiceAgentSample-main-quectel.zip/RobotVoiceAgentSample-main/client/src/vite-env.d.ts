/// <reference types="vite/client" />

// Add module declaration for the font package
declare module '@fontsource-variable/inter';
