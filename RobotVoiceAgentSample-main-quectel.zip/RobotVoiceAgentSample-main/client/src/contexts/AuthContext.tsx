import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { getApiKey, hasApiKey } from '../lib/auth';
import { ApiKeyDialog } from '../components/ApiKeyDialog';

interface AuthContextType {
  isAuthenticated: boolean;
  apiKey: string | null;
  showApiKeyDialog: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [apiKey, setApiKey] = useState<string | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  
  // 初始化时从localStorage加载API密钥
  useEffect(() => {
    const storedApiKey = getApiKey();
    setApiKey(storedApiKey);
    
    // 如果没有API密钥，显示对话框
    if (!hasApiKey()) {
      setIsDialogOpen(true);
    }
  }, []);

  const showApiKeyDialog = () => {
    setIsDialogOpen(true);
  };

  const closeDialog = () => {
    setIsDialogOpen(false);
  };

  const value = {
    isAuthenticated: !!apiKey,
    apiKey,
    showApiKeyDialog,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
      <ApiKeyDialog isOpen={isDialogOpen} onClose={closeDialog} />
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
