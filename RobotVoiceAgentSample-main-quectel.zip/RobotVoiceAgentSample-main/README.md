

## Installation

Amazon Linux 2023:

```sudo
sudo dnf install mesa-libGL
```

Fix bugs:
1. Server lib

-  aws/llm.py: 修复从OpenAIContext upgrade到BedrockContext的类型判断问题
- aws/llm/py: fix issue: when converting from standred message, the text is null if content type no found


2. Client
- @pipecat-ai/small-webrtc-transport: add requestData when connect
