#
# Copyright (c) 2024–2025, Daily
#
# SPDX-License-Identifier: BSD 2-Clause License
#

import os
import argparse
import asyncio
import sys
from contextlib import asynccontextmanager
from typing import Any, Dict, Optional

import aiohttp
import uvicorn
import subprocess
from bots.bot_nova_sonic import nova_sonic_bot
from bots.bot_bedrock_webrtc import bedrock_llm_bot
from dotenv import load_dotenv
from fastapi import (
    BackgroundTasks,
    FastAPI,
    HTTPException,
    Request,
    Depends,
    Header,
    Security,
)
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from loguru import logger
from pipecat_ai_small_webrtc_prebuilt.frontend import SmallWebRTCPrebuiltUI
from pipecat.transports.services.helpers.daily_rest import (
    DailyRESTHelper,
    DailyRoomParams,
)

from pipecat.transports.network.webrtc_connection import (
    IceServer,
    SmallWebRTCConnection,
)

from api import router as api_router
from api.models import BotRequestData

# Load environment variables from .env file
load_dotenv(override=True)

# Maximum number of bot instances allowed per room
MAX_BOTS_PER_ROOM = 2

# Dictionary to track bot processes: {pid: (process, room_url)}
bot_procs = {}

# JWT settings
JWT_SECRET_KEY = os.getenv(
    "JWT_SECRET_KEY", ""
)  # In production, use a secure key from environment
JWT_ALGORITHM = "HS256"
JWT_TOKEN = os.getenv("JWT_AUTH_TOKEN", "")  # Fixed token for testing

# Security scheme
security = HTTPBearer()


async def verify_jwt_token(
    credentials: HTTPAuthorizationCredentials = Security(security),
):
    """
    Verify JWT token for API authentication
    """
    try:
        # For simplicity, we're just checking if the token matches our fixed token
        if credentials.credentials != JWT_TOKEN:
            raise HTTPException(
                status_code=401,
                detail="Invalid authentication credentials",
                headers={"WWW-Authenticate": "Bearer"},
            )
        return True
    except Exception:
        raise HTTPException(
            status_code=401,
            detail="Invalid authentication credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )


# Store Daily API helpers
daily_helpers = {}


def cleanup():
    """Cleanup function to terminate all bot processes.

    Called during server shutdown.
    """
    for entry in bot_procs.values():
        proc = entry[0]
        proc.terminate()
        proc.wait()


def get_bot_file(bot_profile=None):
    """Get the bot implementation file based on the bot profile.

    Args:
        bot_profile (str, optional): The bot profile from request data. Defaults to None.

    Returns:
        str: The bot module path to import

    Raises:
        ValueError: If the bot profile is invalid
    """
    # Default to bedrock if no profile is specified
    bot_implementation = "bedrock"

    # Use bot_profile if provided
    if bot_profile:
        bot_implementation = bot_profile.lower().strip()

    if bot_implementation not in ["bedrock", "nova-sonic"]:
        raise ValueError(
            f"Invalid bot profile: {bot_implementation}. Must be 'bedrock' or 'nova-sonic'"
        )
    return f"bots.bot-{bot_implementation}-daily"


# Store connections by pc_id
pcs_map: Dict[str, SmallWebRTCConnection] = {}

ice_servers = [
    IceServer(
        urls=["stun:stun.miwifi.com:3478", "stun:stun.l.google.com:19302"],
    )
]


@asynccontextmanager
async def lifespan(app: FastAPI):
    """FastAPI lifespan manager that handles startup and shutdown tasks.

    - Creates aiohttp session
    - Initializes Daily API helper
    - Cleans up resources on shutdown
    """
    # Daily startup
    aiohttp_session = aiohttp.ClientSession()
    daily_helpers["rest"] = DailyRESTHelper(
        daily_api_key=os.getenv("DAILY_API_KEY", ""),
        daily_api_url=os.getenv("DAILY_API_URL", "https://api.daily.co/v1"),
        aiohttp_session=aiohttp_session,
    )

    yield  # Run app

    # WebRTC cleanup
    coros = [pc.close() for pc in pcs_map.values()]
    await asyncio.gather(*coros)
    pcs_map.clear()

    # Daily cleanup
    await aiohttp_session.close()
    cleanup()


# Initialize FastAPI app with lifespan manager
app = FastAPI(lifespan=lifespan)

# Configure CORS to allow requests from any origin
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Vite's default development server
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/api")
@app.get("/api/")
async def serve_api(authorized: bool = Depends(verify_jwt_token)):
    """
    API endpoint that requires JWT authentication
    """
    return {
        "websocket-enabled": False,
        "webrtc-enabled": True,
        "daily-enabled": True,
    }


# Include the API router
app.include_router(api_router, prefix="/api")

# Mount the frontend at /webrtc
app.mount("/webrtc", SmallWebRTCPrebuiltUI)


# WebRTC offer
@app.post("/api/offer")
async def offer(
    request: dict,
    background_tasks: BackgroundTasks,
):
    pc_id = request.get("pc_id")

    # Convert request["data"] to BotRequestData model
    bot_data = BotRequestData(**request["data"])

    bot_profile = bot_data.bot_profile

    logger.debug(
        f"bot_profile: {bot_data.bot_profile}, language: {bot_data.language}, conversation_id: {bot_data.conversation_id} "
    )

    if pc_id and pc_id in pcs_map:
        pipecat_connection = pcs_map[pc_id]
        logger.info(f"Reusing existing connection for pc_id: {pc_id}")
        await pipecat_connection.renegotiate(sdp=request["sdp"], type=request["type"])
    else:
        pipecat_connection = SmallWebRTCConnection(ice_servers)
        await pipecat_connection.initialize(sdp=request["sdp"], type=request["type"])

        @pipecat_connection.event_handler("closed")
        async def handle_disconnected(webrtc_connection: SmallWebRTCConnection):
            logger.info(
                f"Discarding peer connection for pc_id: {webrtc_connection.pc_id}"
            )
            pcs_map.pop(webrtc_connection.pc_id, None)

        background_tasks.add_task(
            bedrock_llm_bot if bot_profile == "bedrock" else nova_sonic_bot,
            pipecat_connection,
            bot_data,
        )

    answer = pipecat_connection.get_answer()
    # Updating the peer connection inside the map
    pcs_map[answer["pc_id"]] = pipecat_connection

    return answer


async def create_room_and_token() -> tuple[str, str]:
    """Helper function to create a Daily room and generate an access token.

    Returns:
        tuple[str, str]: A tuple containing (room_url, token)

    Raises:
        HTTPException: If room creation or token generation fails
    """
    room_url = os.getenv("DAILY_SAMPLE_ROOM_URL", None)
    token = os.getenv("DAILY_SAMPLE_ROOM_TOKEN", None)
    if not room_url:
        room = await daily_helpers["rest"].create_room(DailyRoomParams())
        if not room.url:
            raise HTTPException(status_code=500, detail="Failed to create room")
        room_url = room.url

        token = await daily_helpers["rest"].get_token(room_url)
        if not token:
            raise HTTPException(
                status_code=500, detail=f"Failed to get token for room: {room_url}"
            )

    return room_url, token


# Start Daily agent
@app.get("/daily")
async def start_agent(request: Request):
    """Endpoint for direct browser access to the bot.

    Creates a room, starts a bot instance, and redirects to the Daily room URL.

    Returns:
        RedirectResponse: Redirects to the Daily room URL

    Raises:
        HTTPException: If room creation, token generation, or bot startup fails
    """
    print("Creating room")
    room_url, token = await create_room_and_token()
    print(f"Room URL: {room_url}")

    # Check if there is already an existing process running in this room
    num_bots_in_room = sum(
        1
        for proc in bot_procs.values()
        if proc[1] == room_url and proc[0].poll() is None
    )
    if num_bots_in_room >= MAX_BOTS_PER_ROOM:
        raise HTTPException(
            status_code=500, detail=f"Max bot limit reached for room: {room_url}"
        )

    # Spawn a new bot process
    try:
        bot_file = get_bot_file()
        proc = subprocess.Popen(
            [f"python3 -m {bot_file} -u {room_url} -t {token}"],
            shell=True,
            bufsize=1,
            cwd=os.path.dirname(os.path.abspath(__file__)),
        )
        bot_procs[proc.pid] = (proc, room_url)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to start subprocess: {e}")

    return RedirectResponse(room_url)


@app.post("/api/bot/connect")
async def rtvi_connect(request: Request) -> Dict[Any, Any]:
    """RTVI connect endpoint that creates a room and returns connection credentials.

    This endpoint is called by RTVI clients to establish a connection.

    Returns:
        Dict[Any, Any]: Authentication bundle containing room_url and token

    Raises:
        HTTPException: If room creation, token generation, or bot startup fails
    """
    # Parse request body to get bot_profile
    request_data = await request.json()
    bot_profile = request_data.get("bot_profile")
    language = request_data.get("language", "English")
    conversation_id = request_data.get("conversation_id")

    print("Creating room for RTVI connection")
    room_url, token = await create_room_and_token()
    print(f"Room URL: {room_url}")

    # Start the bot process
    try:
        bot_file = get_bot_file(bot_profile)
        proc = subprocess.Popen(
            [
                f"python3 -m {bot_file} -u {room_url} -t {token} -l {language} -c {conversation_id}"
            ],
            shell=True,
            bufsize=1,
            cwd=os.path.dirname(os.path.abspath(__file__)),
        )
        bot_procs[proc.pid] = (proc, room_url)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to start subprocess: {e}")

    # Return the authentication bundle in format expected by DailyTransport
    return {"room_url": room_url, "token": token}


@app.get("/api/bot/status/{pid}")
def get_status(pid: int):
    """Get the status of a specific bot process.

    Args:
        pid (int): Process ID of the bot

    Returns:
        JSONResponse: Status information for the bot

    Raises:
        HTTPException: If the specified bot process is not found
    """
    # Look up the subprocess
    proc = bot_procs.get(pid)

    # If the subprocess doesn't exist, return an error
    if not proc:
        raise HTTPException(
            status_code=404, detail=f"Bot with process id: {pid} not found"
        )

    # Check the status of the subprocess
    status = "running" if proc[0].poll() is None else "finished"
    return JSONResponse({"bot_id": pid, "status": status})


@app.get("/")
async def serve_index():
    return FileResponse("index.html")


# 挂载静态目录到根路径 "/"
# app.mount("/", StaticFiles(directory="static", html=True), name="static")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="WebRTC demo")
    parser.add_argument(
        "--host", default="localhost", help="Host for HTTP server (default: localhost)"
    )
    parser.add_argument(
        "--port", type=int, default=7860, help="Port for HTTP server (default: 7860)"
    )
    parser.add_argument("--reload", action="store_true", help="Reload code on change")
    parser.add_argument("--verbose", "-v", action="count")
    args = parser.parse_args()

    logger.remove(0)
    if args.verbose:
        logger.add(sys.stderr, level="TRACE")
    else:
        logger.add(sys.stderr, level="DEBUG")

    uvicorn.run(
        app,
        host=args.host,
        port=args.port,
        reload=args.reload,
    )
