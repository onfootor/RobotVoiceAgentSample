from pydantic import BaseModel, Field
from typing import Optional


class BotRequestData(BaseModel):
    """Data structure for bot request parameters."""
    
    bot_profile: str = Field(default="bedrock", description="Bot profile to use")
    conversation_id: Optional[str] = Field(default=None, description="Conversation ID for tracking")
    language: str = Field(default="English", description="Language for the conversation")
    model: Optional[str] = Field(default=None, description="LLM model to use")