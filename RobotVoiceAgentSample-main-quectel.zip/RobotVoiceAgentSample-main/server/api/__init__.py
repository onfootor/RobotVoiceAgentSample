from fastapi import APIRouter

from .actions import router as actions_router
from .conversations import router as conversations_router

router = APIRouter()

router.include_router(actions_router)
router.include_router(conversations_router, tags=["Conversations"])
