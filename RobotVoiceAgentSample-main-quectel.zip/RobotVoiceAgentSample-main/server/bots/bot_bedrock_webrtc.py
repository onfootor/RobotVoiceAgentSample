#
# Copyright (c) 2025, Daily
#
# SPDX-License-Identifier: BSD 2-Clause License
#
import os
import sys
from typing import Any
from dotenv import load_dotenv
from loguru import logger

from pipecat.audio.vad.silero import SileroVADAnalyzer
from pipecat.audio.filters.noisereduce_filter import NoisereduceFilter
from pipecat.pipeline.pipeline import Pipeline
from pipecat.pipeline.runner import PipelineRunner
from pipecat.pipeline.task import PipelineParams, PipelineTask
from pipecat.processors.aggregators.openai_llm_context import OpenAILLMContext
from pipecat.services.aws.llm import AWSBedrockLLMService
from pipecat.services.aws.stt import AWSTranscribeSTTService
from pipecat.services.aws.tts import AWSPollyTTSService
from pipecat.transports.base_transport import TransportParams
from pipecat.transports.network.small_webrtc import SmallWebRTCTransport
from pipecat.processors.frameworks.rtvi import (
    RTVIConfig,
    RTVIObserver,
    RTVIProcessor,
)
from bots.http.persistent_context import PersistentContext
from api.models import BotRequestData
from utils.llm_utils import get_model_id_by_name, ROBOT_SYSTEM_INSTRUCTION
from common.dynamodb import get_messages_by_conversation_id, store_messages_to_dynamodb
from bots.tools.zhiyuan_robot import (
    control_robot,
    get_robot_knowledge,
    zhiyuan_robot_tools,
)

load_dotenv(override=True)


async def bedrock_llm_bot(webrtc_connection, request_data: BotRequestData):
    conversationId = request_data.conversation_id
    language = request_data.language
    logger.info(
        f"Starting {request_data.bot_profile} bot, conversationId = {conversationId}, language = {language}, model = {request_data.model}"
    )

    # if language equals chinese, set language_code to zh, else set language_code to en
    language_code = "zh" if request_data.language.lower() == "chinese" else "en"

    transport = SmallWebRTCTransport(
        webrtc_connection=webrtc_connection,
        params=TransportParams(
            audio_in_filter=NoisereduceFilter(),  # Enable noise reduction
            audio_in_enabled=True,
            audio_out_enabled=True,
            vad_analyzer=SileroVADAnalyzer(),
        ),
    )

    stt = AWSTranscribeSTTService(language=language_code)

    # Select appropriate voice based on language code
    voice_id = "Zhiyu" if language_code == "zh" else "Joanna"

    tts = AWSPollyTTSService(
        region="ap-northeast-1",  # only specific regions support generative TTS
        voice_id=voice_id,
        params=AWSPollyTTSService.InputParams(
            engine="neural", language=language_code, rate="1.0"
        ),
    )

    # according to the model name, set the model id
    model_id = await get_model_id_by_name(request_data.model)

    llm = AWSBedrockLLMService(
        aws_region="ap-northeast-1",
        model=model_id,
        params=AWSBedrockLLMService.InputParams(temperature=0.8, latency="standard"),
    )

    llm.register_function("control_robot", control_robot)
    llm.register_function("get_robot_knowledge", get_robot_knowledge)

    history_messages = await get_messages_by_conversation_id(conversationId)
    # filter out system messages
    history_messages = [
        msg.get("content", {})
        for msg in history_messages
        if msg.get("role") != "system"
    ]

    system_messages = [
        {
            "role": "system",
            "content": f"""{ROBOT_SYSTEM_INSTRUCTION} Respond in {language}.""",
        },
    ]
    messages = system_messages + history_messages
    # Calculate the number of existing messages to avoid re-storing them
    # This includes the system message plus any loaded messages from DynamoDB
    existing_messages_count = len(system_messages) + len(history_messages)

    context = OpenAILLMContext(messages, tools=zhiyuan_robot_tools)
    context_aggregator = llm.create_context_aggregator(context)

    storage = PersistentContext(
        context=context, existing_messages_count=existing_messages_count
    )

    rtvi = RTVIProcessor(config=RTVIConfig(config=[]))

    pipeline = Pipeline(
        [
            transport.input(),  # Transport user input
            rtvi,
            stt,  # STT
            context_aggregator.user(),  # User responses
            storage.create_processor(),
            llm,  # LLM
            tts,  # TTS
            transport.output(),  # Transport bot output
            context_aggregator.assistant(),  # Assistant spoken responses
            storage.create_processor(exit_on_endframe=True),
        ]
    )

    task = PipelineTask(
        pipeline,
        params=PipelineParams(
            allow_interruptions=True,
            enable_metrics=True,
            enable_usage_metrics=True,
            report_only_initial_ttfb=True,
        ),
        observers=[RTVIObserver(rtvi)],
    )

    @storage.on_context_message
    async def on_context_message(messages: list[Any]):
        # logger.debug(
        #     f"{len(messages)} message(s) received for storage: {str(messages)}"
        # )
        try:
            await store_messages_to_dynamodb(
                conversation_id=conversationId,
                messages=messages,
                language_code=language,
            )
        except Exception as e:
            logger.error(f"Error storing messages: {e}")
            raise e

    @transport.event_handler("on_client_connected")
    async def on_client_connected(transport, client):
        logger.info("Client connected")
        # Kick off the conversation.
        if not messages:
            messages.append({"role": "user", "content": "Opening"})
        await task.queue_frames([context_aggregator.user().get_context_frame()])

    # Handle client disconnection events
    @transport.event_handler("on_client_disconnected")
    async def on_client_disconnected(transport, client):
        logger.info("Client disconnected")
        await task.cancel()

    runner = PipelineRunner(handle_sigint=False)

    await runner.run(task)
