#
# Copyright (c) 2024–2025, Daily
#
# SPDX-License-Identifier: BSD 2-Clause License
#

"""Bot Implementation.

This module implements a chatbot for natural language processing. It includes:
- Real-time audio/video interaction through Daily
- Speech-to-text using Amazon Transcribe
- Text-to-speech using Amazon Polly
- Support for both English and Chinese

The bot runs as part of a pipeline that processes audio/video frames and manages
the conversation flow.
"""

import asyncio
from typing import Any
import aiohttp
from dotenv import load_dotenv
from loguru import logger
from .runner import configure

from pipecat.audio.vad.silero import SileroVADAnalyzer
from pipecat.pipeline.pipeline import Pipeline
from pipecat.pipeline.runner import PipelineRunner
from pipecat.pipeline.task import PipelineParams, PipelineTask
from pipecat.processors.aggregators.openai_llm_context import OpenAILLMContext
from pipecat.processors.frameworks.rtvi import (
    RTVIConfig,
    RTVIObserver,
    RTVIProcessor,
    RTVIService,
    RTVIServiceOption,
    RTVIServiceOptionConfig,
)
from pipecat.frames.frames import (
    LLMUpdateSettingsFrame,
)
from pipecat.services.aws.llm import AWSBedrockLLMService
from pipecat.services.aws.stt import AWSTranscribeSTTService
from pipecat.services.aws.tts import AWSPollyTTSService
from pipecat.transports.services.daily import DailyParams, DailyTransport
from bots.http.persistent_context import PersistentContext
from common.dynamodb import get_messages_by_conversation_id, store_messages_to_dynamodb
from utils.llm_utils import get_model_id_by_name, ROBOT_SYSTEM_INSTRUCTION
from bots.tools.zhiyuan_robot import (
    control_robot,
    get_robot_knowledge,
    zhiyuan_robot_tools,
)

load_dotenv(override=True)


async def main():
    """Main bot execution function.

    Sets up and runs the bot pipeline including:
    - Daily transport
    - Speech-to-text and text-to-speech services
    - Language model integration
    - Animation processing
    - RTVI event handling
    """
    async with aiohttp.ClientSession() as session:
        (room_url, token, language, conversation_id) = await configure(session)
        # if language equals chinese, set language_code to zh, else set language_code to en
        language_code = "zh" if language.lower() == "chinese" else "en"

        # Set up Daily transport with video/audio parameters
        transport = DailyTransport(
            room_url,
            token,
            "Chatbot",
            DailyParams(
                audio_in_enabled=True,
                audio_out_enabled=True,
                video_out_enabled=False,
                video_out_width=1024,
                video_out_height=576,
                vad_analyzer=SileroVADAnalyzer(),
                # transcription_enabled=True,
                #
                # Language-specific transcription settings
                # transcription_settings=DailyTranscriptionSettings(
                #     language=language_code,
                #     tier="nova",
                #     model="2-general"
                # )
            ),
        )

        history_messages = await get_messages_by_conversation_id(conversation_id)
        # filter out system messages
        history_messages = [
            msg.get("content", {})
            for msg in history_messages
            if msg.get("role") != "system"
        ]

        # Configure STT with language code if supported
        stt = AWSTranscribeSTTService(language=language_code)

        # Select appropriate voice based on language code
        voice_id = "Zhiyu" if language_code == "zh" else "Joanna"

        tts = AWSPollyTTSService(
            region="ap-northeast-1",  # only specific regions support generative TTS
            voice_id=voice_id,
            params=AWSPollyTTSService.InputParams(
                engine="neural", language=language_code, rate="1.0"
            ),
        )

        llm = AWSBedrockLLMService(
            aws_region="ap-northeast-1",
            model="apac.amazon.nova-pro-v1:0",
            params=AWSBedrockLLMService.InputParams(
                temperature=0.8, latency="standard"
            ),
        )

        llm.register_function("control_robot", control_robot)
        llm.register_function("get_robot_knowledge", get_robot_knowledge)

        system_messages = [
            {
                "role": "system",
                "content": f"""{ROBOT_SYSTEM_INSTRUCTION} Respond in {language}.""",
            },
        ]

        messages = system_messages + history_messages

        # Set up conversation context and management
        # The context_aggregator will automatically collect conversation context
        context = OpenAILLMContext(messages, tools=zhiyuan_robot_tools)
        context_aggregator = llm.create_context_aggregator(context)

        # Calculate the number of existing messages to avoid re-storing them
        # This includes the system message plus any loaded messages from DynamoDB
        existing_messages_count = len(system_messages) + len(history_messages)
        storage = PersistentContext(
            context=context, existing_messages_count=existing_messages_count
        )

        rtvi = RTVIProcessor(config=RTVIConfig(config=[]))

        # 1. Define option handler
        async def handle_llm_configure(
            rtvi: RTVIProcessor, service: str, option: RTVIServiceOptionConfig
        ):
            logger.info(f"LLM configured with: {service}, {option.name}={option.value}")
            # according to the model name, set the model id
            model_id = await get_model_id_by_name(option.value)

            frame = LLMUpdateSettingsFrame(settings={option.name: model_id})
            await rtvi.push_frame(frame)

        # 2. Create RTVIService
        llm_service = RTVIService(
            name="llm",
            options=[
                RTVIServiceOption(
                    name="model", type="string", handler=handle_llm_configure
                ),
            ],
        )

        # 3. Register with processor
        rtvi.register_service(llm_service)

        pipeline = Pipeline(
            [
                transport.input(),
                rtvi,
                stt,
                context_aggregator.user(),
                storage.create_processor(),
                llm,
                tts,
                transport.output(),
                context_aggregator.assistant(),
                storage.create_processor(exit_on_endframe=True),
            ]
        )

        task = PipelineTask(
            pipeline,
            params=PipelineParams(
                allow_interruptions=True,
                enable_metrics=True,
                enable_usage_metrics=True,
                report_only_initial_ttfb=True,
            ),
            observers=[RTVIObserver(rtvi)],
        )

        @storage.on_context_message
        async def on_context_message(messages: list[Any]):
            # logger.debug(
            #     f"{len(messages)} message(s) received for storage: {str(messages)}"
            # )
            try:
                await store_messages_to_dynamodb(
                    conversation_id=conversation_id,
                    messages=messages,
                    language_code=language,
                )
            except Exception as e:
                logger.error(f"Error storing messages: {e}")
                raise e

        @transport.event_handler("on_client_connected")
        async def on_client_connected(transport, client):
            logger.info("Client connected")
            # Kick off the conversation.
            if not messages:
                messages.append(
                    {
                        "role": "user",
                        "content": "Please introduce yourself to the user.",
                    }
                )
            await task.queue_frames([context_aggregator.user().get_context_frame()])

        @transport.event_handler("on_first_participant_joined")
        async def on_first_participant_joined(transport, participant):
            print(f"Participant joined: {participant}")
            await transport.capture_participant_transcription(participant["id"])

        @transport.event_handler("on_participant_left")
        async def on_participant_left(transport, participant, reason):
            print(f"Participant left: {participant}")
            await task.cancel()

        runner = PipelineRunner()

        await runner.run(task)


if __name__ == "__main__":
    asyncio.run(main())
