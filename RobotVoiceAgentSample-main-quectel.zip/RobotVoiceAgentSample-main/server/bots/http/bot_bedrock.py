import asyncio
from typing import Any, AsyncGenerator, List, Tuple

from bots.http.frame_serializer import BotFrameSerializer
from bots.http.persistent_context import PersistentContext
from bots.http.rtvi import create_rtvi_processor
from bots.types import BotConfig, BotParams
from common.config import SERVICE_API_KEYS, AWS_CONFIG
from common.dynamodb import (
    default_dynamodb_factory,
    store_messages_to_dynamodb,
    ATTACHMENTS_TABLE,
)
from common.models import AttachmentModel
from fastapi import HTTPException, status
from loguru import logger

from pipecat.pipeline.pipeline import Pipeline
from pipecat.pipeline.runner import PipelineRunner
from pipecat.pipeline.task import PipelineTask, PipelineParams
from pipecat.processors.async_generator import AsyncGeneratorProcessor
from pipecat.processors.frameworks.rtvi import (
    RTVIObserver,
    RTVIActionRun,
    RTVIMessage,
    RTVIProcessor,
)

from pipecat.processors.aggregators.openai_llm_context import OpenAILLMContext
from pipecat.services.aws.llm import AWSBedrockLLMService
from bots.tools.zhiyuan_robot import (
    control_robot,
    get_robot_knowledge,
    zhiyuan_robot_tools,
)
from utils.llm_utils import ROBOT_SYSTEM_INSTRUCTION


async def http_bedrock_bot_pipeline(
    params: BotParams,
    config: BotConfig,
    messages,
    attachments: List[AttachmentModel],
    language_code: str = "chinese",
) -> Tuple[AsyncGenerator[Any, None], Any]:
    """HTTP pipeline using AWS Bedrock for LLM, Transcribe for STT, and Polly for TTS"""

    # Check for AWS credentials
    aws_access_key = SERVICE_API_KEYS.get("aws")
    if aws_access_key is None:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Service `aws` not available in SERVICE_API_KEYS. Please check your environment variables.",
        )

    llm = AWSBedrockLLMService(
        aws_region=AWS_CONFIG["region"],
        model="apac.anthropic.claude-3-7-sonnet-20250219-v1:0",
        params=AWSBedrockLLMService.InputParams(temperature=0.8, latency="standard"),
    )
    llm.register_function("control_robot", control_robot)
    llm.register_function("get_robot_knowledge", get_robot_knowledge)

    system_message = [
        {
            "role": "system",
            "content": f"""{ROBOT_SYSTEM_INSTRUCTION} Respond in {language_code}.""",
        },
    ]

    # filter out system messages
    messages = [msg for msg in messages if msg.get("role") != "system"]

    # combine system message and user messages
    context = OpenAILLMContext(system_message + messages, tools=zhiyuan_robot_tools)
    context_aggregator = llm.create_context_aggregator(context)

    # Calculate the number of existing messages to avoid re-storing them
    # This includes the system message plus any loaded messages from DynamoDB
    existing_messages_count = len(system_message) + len(messages)
    storage = PersistentContext(
        context=context, existing_messages_count=existing_messages_count
    )

    async_generator = AsyncGeneratorProcessor(serializer=BotFrameSerializer())

    #
    # RTVI events for Pipecat client UI
    #

    rtvi = await create_rtvi_processor(config, context_aggregator.user())

    #
    # RTVI events for Pipecat client UI
    #
    # rtvi = RTVIProcessor(config=RTVIConfig(config=[]))

    processors = [
        rtvi,
        context_aggregator.user(),
        storage.create_processor(),
        llm,
        async_generator,
        context_aggregator.assistant(),
        storage.create_processor(exit_on_endframe=True),
    ]

    pipeline = Pipeline(processors)

    runner = PipelineRunner(handle_sigint=False)

    task = PipelineTask(
        pipeline,
        params=PipelineParams(
            allow_interruptions=True,
            enable_metrics=True,
            enable_usage_metrics=True,
        ),
        observers=[RTVIObserver(rtvi)],
    )

    runner_task = asyncio.create_task(runner.run(task))

    @storage.on_context_message
    async def on_context_message(messages: list[Any]):
        logger.debug(
            f"{len(messages)} message(s) received for storage: {str(messages)}"
        )
        try:
            await store_messages_to_dynamodb(
                conversation_id=params.conversation_id,
                messages=messages,
                language_code=language_code,
            )
        except Exception as e:
            logger.error(f"Error storing messages: {e}")
            raise e

    @rtvi.event_handler("on_bot_started")
    async def on_bot_started(rtvi: RTVIProcessor):
        for action in params.actions:
            logger.debug(f"Processing action: {action}")

            # If this is an append_to_messages action, we need to append any
            # attachments. The rule we'll follow is that we should append
            # attachments to the first "user" message in the actions list.
            if action.data.get("action") == "append_to_messages" and attachments:
                for msg in action.data["arguments"][0]["value"]:
                    if msg.get("role") == "user":
                        # Append attachments to this message
                        logger.debug(
                            f"Appending {len(attachments)} attachment(s) to 'user' message"
                        )
                        content = msg.get("content", "")
                        if isinstance(content, str):
                            content = [{"type": "text", "text": content}]
                        for attachment in attachments:
                            # Assume for the moment that all attachments are images
                            content.append(
                                {
                                    "type": "image_url",
                                    "image_url": {
                                        "url": f"data:{attachment.file_type};base64,{attachment.file_data}"
                                    },
                                }
                            )
                            # Delete attachment from DynamoDB
                            await delete_attachment_from_dynamodb(
                                attachment.attachment_id
                            )
                        break

            await rtvi.handle_message(action)

        # This is a single turn, so we just push an action to stop the running
        # pipeline task.
        action = RTVIActionRun(service="system", action="end")
        message = RTVIMessage(type="action", id="END", data=action.model_dump())
        await rtvi.handle_message(message)

    return (async_generator.generator(), runner_task)


async def delete_attachment_from_dynamodb(attachment_id: str):
    """Delete attachment from DynamoDB"""
    try:
        table = default_dynamodb_factory.get_table(ATTACHMENTS_TABLE)
        table.delete_item(Key={"attachment_id": attachment_id})
        logger.debug(f"Deleted attachment {attachment_id}")
    except Exception as e:
        logger.error(f"Error deleting attachment {attachment_id}: {str(e)}")
        # Don't raise the error as this is not critical
