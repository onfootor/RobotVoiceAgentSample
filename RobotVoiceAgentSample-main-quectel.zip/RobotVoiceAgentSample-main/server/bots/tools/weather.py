#
# Copyright (c) 2024–2025, Daily
#
# SPDX-License-Identifier: BSD 2-Clause License
#

"""Weather tools module.

This module provides functions and schemas for weather-related operations
that can be used by different bots.
"""

from datetime import datetime

from pipecat.adapters.schemas.function_schema import FunctionSchema
from pipecat.adapters.schemas.tools_schema import ToolsSchema
from pipecat.services.llm_service import FunctionCallParams


async def fetch_weather_from_api(params: FunctionCallParams):
    """
    Fetch weather information based on provided parameters.
    
    Args:
        params: Function call parameters containing location and format
        
    Returns:
        Weather information including conditions, temperature, format and timestamp
    """
    temperature = 75 if params.arguments["format"] == "fahrenheit" else 24
    await params.result_callback(
        {
            "conditions": "nice",
            "temperature": temperature,
            "format": params.arguments["format"],
            "timestamp": datetime.now().strftime("%Y%m%d_%H%M%S"),
        }
    )


# Weather function schema definition
weather_function = FunctionSchema(
    name="get_current_weather",
    description="Get the current weather",
    properties={
        "location": {
            "type": "string",
            "description": "The city and state, e.g. San Francisco, CA",
        },
        "format": {
            "type": "string",
            "enum": ["celsius", "fahrenheit"],
            "description": "The temperature unit to use. Infer this from the users location.",
        },
    },
    required=["location", "format"],
)

# Create tools schema with weather function
weather_tools = ToolsSchema(standard_tools=[weather_function])
