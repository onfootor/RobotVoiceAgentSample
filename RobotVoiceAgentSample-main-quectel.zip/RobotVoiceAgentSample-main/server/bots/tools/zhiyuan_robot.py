#
# Copyright (c) 2024–2025, Daily
#
# SPDX-License-Identifier: BSD 2-Clause License
#

"""Robot Control tools module.

This module provides functions and schemas for controlling embodied robots
through AWS IoT Core. It enables voice agents to send commands for tasks like
packaging, item manipulation, and status monitoring.
"""

import json
from loguru import logger
import boto3
import os
import pathlib

from dotenv import load_dotenv

from pipecat.adapters.schemas.function_schema import FunctionSchema
from pipecat.adapters.schemas.tools_schema import ToolsSchema
from pipecat.services.llm_service import FunctionCallParams

load_dotenv()

# Available robot commands
ROBOT_COMMANDS = {
    "start_task": "Begin a new robot operation or task",
    "stop_task": "Immediately stop current robot operation",
    "reset_robot": "Return robot to initial position and clear task",
    "get_status": "Retrieve current robot state and task progress",
}

# Path to knowledge base file
KB_FILE_PATH = pathlib.Path(__file__).parent / "zhiyuan_kb.md"


async def get_robot_knowledge(params: FunctionCallParams):
    """
    Retrieve the entire content of the Zhiyuan knowledge base.

    Reads the zhiyuan_kb.md file and returns its contents as a string,
    providing comprehensive information about the Zhiyuan Spirit G1 robot,
    its capabilities, and technical specifications.

    Args:
        params: Function call parameters (no specific parameters required)

    Returns:
        Response object with the knowledge base content
    """
    try:
        # Read the knowledge base file
        with open(KB_FILE_PATH, "r") as kb_file:
            kb_content = kb_file.read()

        logger.info(f"Successfully retrieved knowledge base from {KB_FILE_PATH}")

        # Return success response with the knowledge base content
        await params.result_callback(
            {
                "status": "success",
                "content": kb_content,
                "message": "Successfully retrieved Zhiyuan knowledge base",
            }
        )

    except Exception as e:
        logger.error(f"Error retrieving knowledge base: {e}")
        await params.result_callback(
            {
                "status": "error",
                "error": str(e),
                "message": "Failed to retrieve Zhiyuan knowledge base",
            }
        )


async def control_robot(params: FunctionCallParams):
    """
    Send control commands to a robot via AWS IoT Core.

    Publishes command messages to the robot's designated IoT topic,
    enabling remote operation of industrial robots for tasks like
    packaging, item manipulation, and system management.

    Args:
        params: Function call parameters containing the command to execute
               and optional robot identifier

    Returns:
        Response object with command status, robot name, and result message
    """
    command = params.arguments["command"]
    robot_name = params.arguments.get("robot_name", "zhiyuan-robot-01")
    topic = f"robot/{robot_name}/control"

    # Prepare the message payload
    payload = {"command": command}

    try:
        # Initialize AWS IoT client
        iot_client = boto3.client(
            "iot-data",
            aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID", ""),
            aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY", ""),
            region_name=os.getenv("AWS_REGION", "ap-northeast-1"),
        )
        # Publish message to IoT Core
        response = iot_client.publish(topic=topic, qos=1, payload=json.dumps(payload))

        logger.info(
            f"Successfully published command '{command}' to topic '{topic}', response: {response}"
        )

        # Return success response
        await params.result_callback(
            {
                "status": "success",
                "command": command,
                "robot_name": robot_name,
                "message": f"Successfully sent {ROBOT_COMMANDS.get(command, command)} command to robot",
            }
        )

    except Exception as e:
        logger.error(f"Error publishing to IoT Core: {e}")
        await params.result_callback(
            {
                "status": "error",
                "command": command,
                "robot_name": robot_name,
                "error": str(e),
                "message": f"Failed to send {ROBOT_COMMANDS.get(command, command)} command to robot",
            }
        )


# Robot control function schema definition
robot_control_function = FunctionSchema(
    name="control_robot",
    description="Control the robot to perform physical tasks in a workspace. The robot can handle packaging operations, item manipulation (grasping, moving, placing), and respond to system commands. Use natural language instructions that will be mapped to appropriate robot actions.",
    properties={
        "command": {
            "type": "string",
            "enum": list(ROBOT_COMMANDS.keys()),
            "description": "Robot command to execute: start_task (begin a new operation like packaging items or moving objects between locations), stop_task (immediately stop current operation for safety), reset_robot (return to initial position and clear current task), get_status (retrieve current operation state, position, and task progress).",
        },
        "robot_name": {
            "type": "string",
            "description": "Identifier for the specific robot to control (default: zhiyuan-robot-01)",
        },
    },
    required=["command"],
)

# Knowledge base retrieval function schema definition
knowledge_base_function = FunctionSchema(
    name="get_robot_knowledge",
    description="Retrieve comprehensive information about the Zhiyuan Spirit G1 robot, including its capabilities, core technologies, how its intelligent voice interaction system is built, and sample interactions.",
    properties={},
    required=[],
)

# Create tools schema with robot control and knowledge base functions
zhiyuan_robot_tools = ToolsSchema(
    standard_tools=[robot_control_function, knowledge_base_function]
)
